package com.nataliasep.contactsfragment;

public interface IContactoListener {
    void onClick(int position);
}
