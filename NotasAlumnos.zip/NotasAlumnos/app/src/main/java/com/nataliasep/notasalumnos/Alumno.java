package com.nataliasep.notasalumnos;

import java.io.Serializable;
import java.util.Calendar;

public class Alumno implements Serializable {

    private final int nia;
    private final String nombre;
    private final String apellido1;
    private final String apellido2;
    private final String fchNacimiento;
    private final String email;
    private final Nota[] notas;

    public Alumno(int nia, String nombre, String apellido1, String apellido2, String fchNacimiento, String email, Nota[] notas) {
        this.nia = nia;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.fchNacimiento = fchNacimiento;
        this.email = email;
        this.notas = notas;
    }

    public int getNia() {
        return nia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public String getFchNacimiento() {
        return fchNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public Nota[] getNotas() {
        return notas;
    }

    /*public int getEdad(){
        int edad;
        Calendar today = Calendar.getInstance();
        int añoActual = today.get(Calendar.YEAR);
        int añoNacimiento = fchNacimiento.get(Calendar.YEAR);
        return edad;
    }*/
}
