package com.nataliasep.notasalumnos;

public interface IClickListener {
    void onClick(int position);
}
